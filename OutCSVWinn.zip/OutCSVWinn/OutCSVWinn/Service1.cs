﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace OutCSVWinn
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            var filePath = ConfigurationManager.AppSettings["FileLocation"];
            fileSystemWatcher1.Path =filePath ;//C:\OutSurance
            fileSystemWatcher1.Changed += FileSystemWatcher1_Changed;
            fileSystemWatcher1.Created += FileSystemWatcher1_Changed;
            
        }

        
        private void FileSystemWatcher1_Changed(object sender, System.IO.FileSystemEventArgs e)
        {
            string fileLocation = e.FullPath;
            Utils ut = new Utils();
            ut.ReadCSV(fileLocation);
        }

        protected override void OnStop()
        {
        }
    }
}
