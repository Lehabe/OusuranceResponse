﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OutCSVWinn
{
    public class Utils
    {
        public void ReadCSV(string filePath)
        {
            //Specify the excel provider for .xlsx file type and the file path which contain the excel file
            string csvData = System.IO.File.ReadAllText(filePath);



            try
            {
                List<CSVTemplate> tempList = new List<CSVTemplate>();
                int counter = 0;
                foreach (string row in csvData.Split('\n'))
                {                   
                    if (!string.IsNullOrEmpty(row))
                    {
                        string[] cols = row.Split(',');
                        //Execute a loop over the columns.
                        if (counter == 0)
                        {
                            counter++;
                            continue;// skip column names, first row
                        }                        
                        if (cols.Count() > 2)
                        {
                            var firstName = cols[0];
                            var lastName = cols[1];
                            var address = cols[2];
                            var phoneNo = cols[3];

                            CSVTemplate rec = new CSVTemplate();
                            rec.Address = address.ToString();
                            rec.FirstName = firstName.ToString();
                            rec.LastName = lastName.ToString();
                            rec.PhoneNumber = phoneNo.ToString();
                            tempList.Add(rec);
                            counter++;

                        }
                    }
                }
                SortOder so = new SortOder();                          
                WriteToFile(so.SortNamesCount(tempList), Path.GetDirectoryName(filePath) + @"\Output\nc" + Path.GetFileNameWithoutExtension(filePath) + ".txt");

                WriteToFile(so.SortAddress(tempList), Path.GetDirectoryName(filePath) + @"\Output\ad" + Path.GetFileNameWithoutExtension(filePath) + ".txt");

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void WriteToFile(List<string> listFile,string path)
        {
          using (System.IO.StreamWriter file =
          new System.IO.StreamWriter(path))
            {
                foreach (string line in listFile.ToArray())
                {
                    // If the line doesn't contain the word 'Second', write the line to the file.
                   
                        file.WriteLine(line);
                    
                }
            }

        }

        


    }
}
