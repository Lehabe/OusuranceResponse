﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OutCSVWinn
{
     public class CSVTemplate
    {
        public string FirstName;        
        private string first_name
        {
            get
            {
                return this.FirstName;
            }
            set
            {
                this.FirstName = value;
            }
        }
        public string LastName;
        private string last_name
        {
            get
            {
                return this.LastName;
            }
            set
            {
                this.LastName = value;
            }
        }
        public string Address;
        private string address
        {
            get
            {
                return this.Address;
            }
            set
            {
                this.Address = value;
            }
        }

        public string PhoneNumber;
        private string phone_number
        {
            get
            {
                return this.PhoneNumber;
            }
            set
            {
                this.PhoneNumber = value;
            }
        }

        public CSVTemplate()
        {

        }
    }
}
