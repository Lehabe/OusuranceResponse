﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OutCSVWinn
{
    public class SortOder
    {
        public List<string> SortNamesCount(List<CSVTemplate> list)
        {

            List<string> ls = new List<string>();

            var groups = from p in list
                         orderby p.LastName ascending
                         group p by p.LastName
                         into g
                         select new
                         {
                             Name = g.Key,
                             Count = g.Count()
                         };
            groups = groups.OrderByDescending(b => b.Count);
            foreach (var groupedCol in groups)
            {
                ls.Add(groupedCol.Name + "," + groupedCol.Count);
            }

            return ls;
        }



        public List<string> SortAddress(List<CSVTemplate> list)
        {

            List<string> ls = new List<string>();
            List<Address> listAddress = new List<Address>();

            for(int i=0; i<list.Count; i++)
            {
                string[] address = list[i].Address.Split(' ');
                if(address.Count() > 1)
                {
                    Address newAddress = new Address();
                    newAddress.No = address[0];
                    newAddress.Street = address[1];
                    listAddress.Add(newAddress);
                }
            }


            var orderedList = from p in listAddress
                         orderby p.Street ascending
                         select p;

            foreach (var order in orderedList)
            {
                ls.Add(order.ToString());
            }

            return ls;

        }
    }

    public class Address
    {
        public string No { get; set; }
        public string Street { get; set; }
        
        public override string ToString()
        {
            return string.Format("{0} {1}", No, Street);
        }
    }

}

