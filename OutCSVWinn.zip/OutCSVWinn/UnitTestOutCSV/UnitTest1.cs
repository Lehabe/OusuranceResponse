﻿using OutCSVWinn;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OutCSVWinn.Tests
{
    [TestClass()]
    public class UnitTest1
    {
        [TestMethod()]
        public void ReadCSVTest()
        {
            Utils utils = new Utils();
            utils.ReadCSV(@"C:\OutSurance\data.csv");
           
        }
    }
}

